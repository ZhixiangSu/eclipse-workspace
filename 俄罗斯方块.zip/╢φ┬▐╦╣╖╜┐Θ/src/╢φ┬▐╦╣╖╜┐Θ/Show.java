package ����˹����;
public class Show implements Runnable
{
	@Override
	public void run() {
		// TODO Auto-generated method stub
		MainUI.setallenable(false);
		anim.addpart(part);
		MainUI.setallenable(true);
	}
	Part part;ShowAnim anim;
	public Show(Part part,ShowAnim anim) {
		// TODO Auto-generated constructor stub
		this.anim=anim;
		this.part=part;
	}
	
}
