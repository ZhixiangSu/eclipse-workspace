package ����˹����;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Paint;

import javax.swing.JPanel;

public class Square extends JPanel
{
	int x,y;
	public Square(int x,int y) {
		// TODO Auto-generated constructor stub
		this.x=x;this.y=y;
		setBounds(x, y, 50, 50);
		setBackground(Color.BLUE);
	}
}
