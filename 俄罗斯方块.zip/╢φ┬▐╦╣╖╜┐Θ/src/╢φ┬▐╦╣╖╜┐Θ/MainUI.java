package ����˹����;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class MainUI 
{
	static Integer count=0;
	static Part parts[]=new Part[5];
	static boolean part1[][]=
		{
			{true,true,true,true},
		};
	static boolean part2[][]=
		{
				{false,true,false},
				{true,true,true}
		};
	static boolean part3[][]=
		{
				{true,true,false},
				{false,true,true}

		};
	static boolean part4[][]=
		{
				{true,true},
				{true,true}
		};
	static JFrame frame=new JFrame("����˹����");
	static JPanel p1=new JPanel();
	static JPanel p2=new JPanel();
	static JPanel p3=new JPanel();
	static JLabel l1=new JLabel(count.toString(),JLabel.CENTER);
	static ShowAnim anim=new ShowAnim(16,10);
	static JButton bt1=new JButton("1");
	static JButton bt2=new JButton("2");
	static JButton bt3=new JButton("3");
	static JButton bt4=new JButton("4");
	
	public static void main(String args[])
	{
		frame.setSize(700, 900);
		frame.setLayout(null);
		frame.add(anim);
		frame.add(p2);
		frame.add(p3);
		frame.setVisible(true);
		
		anim.setBounds(0, 0, 500, 800);
		anim.setBackground(Color.gray);
		anim.setLayout(null);
		
		p2.setBackground(Color.yellow);
		p2.setBounds(510, 0, 160, 190);
		p2.setLayout(new BorderLayout());
		p2.add(l1,BorderLayout.CENTER);
		
		p3.setBounds(510, 200, 160,600);
		p3.setBackground(Color.blue);
		p3.setLayout(new GridLayout(4,1));
		p3.add(bt1);
		p3.add(bt2);
		p3.add(bt3);
		p3.add(bt4);
		
		l1.setFont(new Font("����", Font.BOLD, 50));
		
		parts[1]=new Part(part1);
		parts[2]=new Part(part2);
		parts[3]=new Part(part3);
		parts[4]=new Part(part4);
		bt1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Show s1=new Show(parts[1], anim);
				anim.requestFocus();
				Thread t1=new Thread(s1);
				t1.start();
				t1=null;
			}
		});
		bt2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Show s1=new Show(parts[2], anim);
				anim.requestFocus();
				Thread t1=new Thread(s1);
				t1.start();
			}
		});
		bt3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Show s1=new Show(parts[3], anim);
				anim.requestFocus();
				Thread t1=new Thread(s1);
				t1.start();
			}
		});
		
		bt4.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Show s1=new Show(parts[4], anim);
				anim.requestFocus();
				Thread t1=new Thread(s1);
				t1.start();
			}
		});
	}
	static boolean setallenable(boolean t)
	{
		bt1.setEnabled(t);
		bt2.setEnabled(t);
		bt3.setEnabled(t);
		bt4.setEnabled(t);
		return t;
	}
}
