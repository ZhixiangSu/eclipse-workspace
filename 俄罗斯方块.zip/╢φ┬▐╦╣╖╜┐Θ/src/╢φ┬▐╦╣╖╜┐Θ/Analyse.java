package ����˹����;

import java.util.LinkedList;
import java.util.Queue;

public class Analyse 
{
	Queue<Integer> queue=new LinkedList<>();
	public Analyse(ShowAnim anim,Part part) 
	{
		// TODO Auto-generated constructor stub
	}
}
